import React from 'react';
import Page from './components/Page';
import { connect } from '@holochain/hc-web-client';
import './styles/App.scss';
import Editor from './components/Editor';
import PreviewSection from './components/PreviewSection';
import { MdCreate } from "react-icons/md";

//ParentA component
class App extends React.Component {

  constructor(props) {
      super(props);

      this.intrfzPage = {
        title: '',
        sections: [],
        position: undefined
      };

      this.state = {
        currentURLParemter: [],
        parameters: [],
        titles: [],
        contents: [],
        hash: '',
        titlenp : '',
        contentsnp: [],
        renderedPages: [],
        links: [],
        addresses: [],



        existingPages: [], //array de json { title:, address, }
        pages: [], // array de json {title:, address:, sections: [{content:, address:,} ...]}
        newData: {
          title: '',
          sections: [
          ]
        },
        statusPreload: '',
        dataPage: this.intrfzPage,
        existingPage: false,
        editorSettings: [],
        previewData: {}
      };
      
  }

  componentDidMount() {
    connect({ url: "ws://192.168.1.63:8885" })
      .then(({callZome, close}) => {
        callZome('wiki', 'wiki', 'get_home_page') ({})
        .then( response => {
          var page;
          response = JSON.parse(response);
          if (response.Err) {
            page = {
              title: 'Welcome to H-wiki',
              sections: [{
                content: 'This is the page of H-wiki'
              }]
            };
          } else {
            page = {
              title: response.Ok.titulo,
              sections: response.Ok.sections
            };
          }
          console.log(page)
          this.setState({ pages: [page]});
        })
    })
  }
    
  handleToUpdate(e){
    e.preventDefault();
    
    connect({ url: "ws://192.168.1.63:8885" }).then(({callZome, close}) => {
        callZome('wiki', 'wiki', 'get_page') ({
          titulo: e.target.textContent
        })
        .then( page => {
            page = JSON.parse(page);
            page = page.Ok;
            
            var npage = {
              title: page.titulo,
              sections: []
            }
            for(var i in page.sections) {
              npage.sections[i] = {
                element_content: page.sections[i].redered_page_element.element_content
              } 
            }
            

            let el = e.target,
                cont = 2,
                parent = el.parentNode,
                pos;
          
          for (var j = 0; i<cont; j++) {
            if (parent.dataset.page) {
              pos = parent.dataset.page;
              break
            } 
            parent = parent.parentNode;
            cont+=1;
          }     
          var currentPages = this.state.pages;
          currentPages.splice((parseInt(pos)+1), currentPages.length-1);

          var nvsPages = [...currentPages, npage];

      
          this.setState({
            pages: nvsPages
          })
        })
      });

      /**
       * 0: {parent_page_anchor: null,
       *       element_type: "text", 
       *        element_content: "[mi primera pagina](#)"}
        *  title: "home page"
       */
    // e.preventDefault();
    

    // connect({ url: "ws://192.168.1.63:8800" }).then(({callZome, close}) => {
    //     callZome('wiki', 'wiki', 'get_all') ({
    //       address: address
    //     })
    //     .then( page => {
    //       page = JSON.parse(page);
    //       console.log(page)
    //       page = page.Ok;

    //       var data = {
    //         title: page.page.titulo,
    //         address: page.page_name,
    //         sections: []
    //       };
    //       var cSections = page.redered_page_element;

    //       for(var j in cSections) {
    //         data.sections[j] = {};
    //         data.sections[j].content = cSections[j].element_content;
    //         data.sections[j].render = cSections[j].element_content;
    //         data.sections[j].address = page.vector_address[j]
    //       }
          
    //       var renderedPages = [data];
    //       // console.log(renderedPages)
    //       var updatedPages = [...currentPages, <Page handleToUpdate = {this.handleToUpdate.bind(this)} data = {data} />]
    //       this.setState({
    //         pages: updatedPages,
    //         renderedPages: [...this.state.renderedPages, renderedPages]
    //       })
    //     })
    // });
  }

  closeModal = () => {    
    document
      .querySelector('#modal-create-page')
        .style.display = 'none';
  }

  showModal = () => {    
    document
      .querySelector('#modal-create-page')
        .style.display = 'flex';
  }

  openEditor = (pos = null, mode) => {
    let options = [{
      pos: pos,
      mode: mode
    }];

    this.setState({
      editorSettings: options
    }, function(){
      document
        .querySelector('#modal-add-section')
          .style.display = 'flex';
    })
  }

  updateSectionPage(pos, content, mode = null) {

    var section = {
      parent_page_anchor: "",
      element_type: "text",
      element_content: content.markdown,
      render: content.markdown
    },
    contentsnp = this.state.contentsnp,
    _this = this,
    pEnd;

    if (mode === 'addSB' || mode === 'add') {
      pos = mode === 'add' ? contentsnp.length : (parseInt(pos)+1);
      pEnd=0;
    } else if (mode === 'edit') {
      pEnd=1;
    }
    contentsnp.splice(pos, pEnd, section);
    this.setState({
      contentsnp: []
    }, function() {
      _this.setState({
        contentsnp: contentsnp
      }, function(){
        document
          .querySelector('#modal-add-section')
            .style.display = 'none';
      })
    })
    console.log(mode);
  }

  storePage = () => {
    var _this = this;
    connect({ url: "ws://192.168.1.63:8885" }).then(({callZome, close}) => {
        callZome('wiki', 'wiki', 'create_page_with_elements') ({
          titulo: _this.state.dataPage.title,
          contents:_this.state.dataPage.sections,
        })
        .then( r => {
          console.log(r)
          _this.setState({
            newData: {
              title: '',
              sections: [],
              position: undefined
            }
          }, () => {
            _this.closeModal();
            window.location.reload()
          });
        })
    })
  }






















  showEditorModal = (mode, pos = undefined) => {    
    this.setState({
      editorSettings: [{
        mode: mode,
        pos: pos
      }]
    }, ()=>{
      document
        .querySelector('#modal-add-section')
          .style.display = 'flex';
    });
  }

  closeEditorModal(){
    this.setState({
      editorSettings: []
    }, ()=>{
      document
        .querySelector('#modal-add-section')
          .style.display = 'none';
    });
  }

  showPageModal = () => {
    document
      .querySelector('#modal-create-page')
        .style.display = 'flex';
  }

  showModalCreatePage = () =>{
    var _this = this,
        data = this.intrfzPage;
    this.setState({
      dataPage: data,
      existingPage: false,
    }, ()=> {
      console.log(_this.state.dataPage);
      _this.showPageModal();
    });
  }  

  closeModalCreatePage = () => {
    console.log('close create page')
    if (this.state.existingPage) {
      var pages = this.state.pages,
          pos = this.state.dataPage.pos;

      pages[pos] = this.state.previewData;
      delete pages[pos].pos;

      this.setState({
        pages: pages
      })
      console.log('close create 2')

    } else {
      console.log('close create 1')
      this.setState({
        newData: {
        title: '',
        sections: [],
        position: undefined
      }
      })
    }
    document
      .querySelector('#modal-create-page')
        .style.display = 'none';
   }

  showPage = (pos) => {
    var _this = this,
        currentPage = this.state.pages[pos];

    currentPage.position = pos;

    this.setState({
      dataPage: currentPage,
      previewData: currentPage,
      existingPage: true
    }, ()=> {
      _this.showPageModal();
    });
  }

  getPagePosition = (e)=> {
    let el      = e.target,
        parent  = el.parentNode,
        cont    = 2,
        pos;

    for (var i = 0; i<cont; i++) {
      if (parent.dataset.page) {
        pos = parent.dataset.page;
        break
      } 

      parent = parent.parentNode;
      cont+=1;
    }
    return parseInt(pos);
  }

  updatePageTitle = (e)=> {
      let dataPage = this.state.dataPage;
      dataPage.title = e.target.value;
      this.setState({ dataPage: {...dataPage} });
  }

  getContentSection = (pos) =>{
    return this.state.dataPage.sections[pos].element_content;
  }

  updatePageSections(mode, pos, content) {

    let _this = this,
        ini = pos,
        end,
        section = {
          element_type: 'text',
          element_content: content
        },
        currentDataPage = this.state.dataPage;

    if (mode === 'add') {
      ini = (parseInt(pos)+1);
      end = 0;
    } else if (mode === 'edit') {
      end = 1;
    }

    currentDataPage.sections.splice(ini, end, section);

    this.setState({
      dataPage: currentDataPage
    }, () =>{
      _this.closeEditorModal();
    })
  }

  editSection = (e) =>  {
    console.log('edit section')
  }

  updateSection = (e) => {
    console.log('update section')
  }

  removeSection = (pos) => {
    console.log(pos)
  }

  render() {
    return (
      <div id='container'>

        <header>
          <div>
              <div></div>
          </div>
          <div>
            <button onClick={this.showModalCreatePage}>Create page</button>
          </div>
        </header>

        <section>
          <div>
            {this.state.pages.map((dataPage, key) => {
                return (
                  <div key={key} data-page={key}>
                    <div>
                      {key !== 0 && <button onClick={e =>{this.showPage(key)}}>
                        <MdCreate />
                      </button>}
                    </div>
                    <Page data={dataPage} handleToUpdate = {this.handleToUpdate.bind(this)}  />
                  </div>
                )
              })}
          </div>
        </section>

        {/*MODAL PARA GESTION DE PAGINA*/}
        <div id='modal-create-page'>
          <div>
            <header>
              <label>Create page</label>
            </header>
            <section>
              <div>
                <input 
                  type='text'
                  value={this.state.dataPage.title}
                  onChange={this.updatePageTitle}
                  placeholder='Page title'
                  className={this.state.existingPage ? 'readonly' : ''}
                />
              </div>
              <div>
                {this.state.dataPage.sections.map((data, key) => {
                  return(
                    <PreviewSection 
                      key = {key}
                      pos = {key}
                      content = {data.element_content}
                      showEditorModal = {this.showEditorModal.bind(this)}
                      removeSection = {this.removeSection.bind(this)}
                    />
                  )
                })}

              </div>
            </section>
            <footer>
              <div>
                <div>
                  {this.state.dataPage.sections.length === 0 &&
                    <button onClick={e=>{this.showEditorModal('add')}}>Add new section</button>
                  }

                  {this.state.existingPage && <button>Delete page</button> }
                </div>
              </div>
              <div>
                <div>
                  <button onClick={this.closeModalCreatePage}>Cancel</button>
                  <button onClick={this.storePage}>Save</button>
                </div>
              </div>
            </footer>
          </div>
        </div>


        {/*MODAL PARA EL EDITOR*/}
        <div id='modal-add-section'>
          <div>
              {this.state.editorSettings.map((param, key) => {
                return(
                  <Editor
                    key = {key}
                    pos = {param.pos}
                    mode = {param.mode}
                    getContentSection = {this.getContentSection.bind(this)}
                    updatePageSections = {this.updatePageSections.bind(this)}
                    closeEditorModal = {this.closeEditorModal.bind(this)}
                  />
                )
              })}
          </div>
        </div>

        <div id='preload'>
            <div>
              <label>{this.state.mPreload}</label>
            </div>
        </div>

      </div>
    )
  }
}


export default App;
