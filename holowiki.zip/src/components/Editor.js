import React from 'react'
import MdEditor from 'react-markdown-editor-lite'
import MarkdownIt from 'markdown-it';
import '../styles/Editor.scss';

export default class Editor extends React.Component {
  mdEditor = null
  mdParser = null
  content = ''
  constructor(props) {
    super(props)
    this.mdParser = new MarkdownIt()
  }
  
  updatePageSections = () => {
    this.props.updatePageSections(this.props.mode, this.props.pos, this.mdEditor.getMdValue());
  }
  
  closeEditorModal = () => {    
    this.props.closeEditorModal();
  }

  render() {
    return (      
      <div id="rmel-container">
        <header>
          <label>MdEditor</label>
        </header>
        <div>
          {this.props.mode === 'edit'
            ? 
              <MdEditor
                ref={node => this.mdEditor = node}  
                value={this.props.getContentSection(this.props.pos, this.props.mode)}
                renderHTML={(text) => this.mdParser.render(text)}
              />
            :
              <MdEditor
                ref={node => this.mdEditor = node}  
                value=''
                renderHTML={(text) => this.mdParser.render(text)}
              />
          }
        </div>
        <footer>
          <div>
            <button onClick={this.closeEditorModal}>Cancel</button>
            <button onClick={this.updatePageSections}>Add</button>
          </div>
        </footer>               
      </div>
    )
  }
}