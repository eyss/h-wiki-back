import React from 'react';
import '../styles/PreviewSection.scss';
import MarkdownRenderer from 'react-markdown-renderer'
import {MdClear} from "react-icons/md"; 

export default class PreviewSection extends React.Component {
    // eslint-disable-next-line no-useless-constructor
    constructor(props) {
      super(props);
    }

    showEditorModal = (mode) => {
      this.props.showEditorModal(mode, this.props.pos)
    }

    removeSection = () => {
      this.props.removeSection(this.props.pos)
    }

    render() {
        return(
            <div className='preview-section'>
                <div>
                  <MarkdownRenderer markdown={!this.props.element_content ? this.props.content : this.props.element_content } />
                  <div>
                    <div>
                      <button onClick={e => {this.showEditorModal('edit')}}>Edit</button>
                      <button onClick={e => {this.showEditorModal('add')}}>Add section below</button>
                    </div>
                  </div>

                </div>

                <div>
                  <div>
                    <button onClick={this.removeSection}><MdClear /></button>
                  </div>
                </div>
                
            </div>
        )
    }
}